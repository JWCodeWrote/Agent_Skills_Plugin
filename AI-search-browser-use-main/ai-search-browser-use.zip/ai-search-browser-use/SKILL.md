---
name: ai-search-browser-use
description: Use this skill when a task needs AI-assisted web research via a real browser with OS detection, prioritized browser selection (Chrome, then Quark, then Comet), optional Chrome installation, and consolidated answers with citations.
---

# AI Search Browser Use

## Overview
Enable reliable AI-assisted web research by selecting the best available browser (Chrome first, then Quark, then Comet), running Gemini/Qwen/Comet queries, synthesizing results, and closing the browser when finished.

## Workflow

### 1) Plan browser selection and OS handling
- Run `scripts/browser_plan.py --json` to detect OS, find installed browsers, and produce open/close commands.
- If no supported browser is installed, install Chrome using the provided command:
  - macOS: `brew install --cask google-chrome`
  - Windows: `winget install --id Google.Chrome -e`
- Rerun `scripts/browser_plan.py --json` after install to confirm the selected browser.
- If Quark or Comet are installed under nonstandard paths, set `BROWSER_PATH_OVERRIDES` as JSON before rerunning, e.g.:
  - `BROWSER_PATH_OVERRIDES='{"quark":["/Custom/Path/Quark.app"]}'`

### 2) Launch browser (priority: Chrome → Quark → Comet)
- Prefer the selected browser from the plan output.
- Use the plan’s `open_command` if automation is not available.
- If browser automation is available (e.g., browser-use/agent-browser), drive the browser through that tool but still honor the priority order.

### 3) Run AI searches and collect sources
- Use **Gemini** and **Qwen** as the primary AI search engines.
- Use **Comet** AI search if the Comet browser exposes it; otherwise use Comet as a normal browser.
- Follow `references/ai_search_targets.md` for public entry URLs.
- Use the same query prompt across engines for comparability.
- Extract:
  - Key claims
  - Supporting sources (prefer official or primary references)
  - Dates and any conflicting statements

### 4) Synthesize and cite
- Consolidate results into a single, coherent answer.
- Highlight consensus points first, then disagreements or uncertainties.
- Provide citations for each major claim using this format:
  - `Source Title — Domain — URL`
- If the AI answers do not provide sources, open the referenced sites and cite the primary sources directly.

### 5) Close browser
- Use the plan’s `close_command`, or the automation tool’s close/quit action.
- Ensure all browser instances opened during the task are closed.

## Outputs
- Final answer with integrated reasoning from multiple AI engines.
- Explicit citations showing where each major claim was found.

## Resources
- `scripts/browser_plan.py`: Detect OS, select browser, and provide open/close/install commands.
- `references/ai_search_targets.md`: Public entry points for Gemini/Qwen/Comet and citation guidance.
